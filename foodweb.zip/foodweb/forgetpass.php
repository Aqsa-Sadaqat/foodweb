<?php
session_start();

include('db.php');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $gmail = $_POST['email'];
    $pass1 = $_POST['pas1'];
    $pass2 = $_POST['pas2'];

    $checkuser = "SELECT * FROM form WHERE email='$gmail'";
    $result = mysqli_query($con, $checkuser);
    $count = mysqli_num_rows($result);

    if ($count > 0) {
        if ($pass1 == $pass2) {
            // Update the password
            $update_query = "UPDATE form SET pass = '$pass1' WHERE email = '$gmail'";
            $update_result = mysqli_query($con, $update_query);

            if ($update_result) {
                 echo "<script type='text/javascript'> alert('Password is changed')</script>";
                header("location: signin.php");
                exit; // Always good practice to exit after a header redirect
            } else {
                echo "<script type='text/javascript'> alert('Failed to update password')</script>";
            }
        } else {
            echo "<script type='text/javascript'> alert('Passwords do not match')</script>";
        }
    } else {
        echo "<script type='text/javascript'> alert('Wrong Email Address')</script>";
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foode.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
     <link rel="stylesheet" href="loginsignup.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

</head>
<body>
    <a href="index.html" class="btn">back</a>
  <center>
    <div class="container" id="signup" >
        <h1 class="form-title">Forget Password</h1>
        <form method="post" action="">
            
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="email" placeholder="Email" required >
                
            </div>
            <br>
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="pas1" id="password" placeholder="Password" required >
               
            </div>
            <br>
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="pas2" id="password" placeholder="Password" required >
               
            </div>
            <br>
            <input type="submit" class="btn" value="Send" name="signup">




        </form>
        <p class="or">
            --------------or-------------
        </p>
    
        <div class="links">
            <p>Already Have Account ?</p>
             <a href="signin.php" id="signInButton" class="add">Sign In</a>
            <button ></button>

        </div>
   


    </div>
 </center>
    

  
     

    
    
 

    
  

    
    








 <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
 <script src="script.js"></script>
</body>
