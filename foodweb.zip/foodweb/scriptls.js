// const signUpButton = document.getElementById('signUpButton');
// const signInButton = document.getElementById('signInButton');
// const signInForm = document.getElementById('signIn');
// const signUpForm = document.getElementById('signUp');

// signUpButton.addEventListener('click',function(){
//     signInForm.style.display="none";
//     signUpForm.style.display="block";
// })
// signInButton.addEventListener('click', function(){
//     signInForm.style.display="block";
//     signUpForm.style.display="none";
// })
var x = document.getElementById("login");
     var y = document.getElementById("register");
     var z = document.getElementById("btn");

     function register(){
        x.style.left = "-480px";
        y.style.left = "50px";
        z.style.left = "110px";
     }
     function login(){
        x.style.left = "50px";
        y.style.left = "450px";
        z.style.left = "0px";
     }