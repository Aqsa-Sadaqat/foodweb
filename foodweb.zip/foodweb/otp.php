<?php
 
include('db.php');
   session_start();
if(isset($_POST['submit'])){
    echo"enter";
    $gmail = $_POST['email'];
    $rand = rand(000000,999999);
    $query = "select *from form";
    $query2 = mysqli_query($con,$query);
    $select_rows = mysqli_fetch_assoc($query2);
    $select_email = $select_rows['email'];
    if ($select_email == $gmail){
        echo"enter2";
        header("location: dashbaord.php");
        die;

        // $to = $gmail;
        // $subject = "Verification Code : $rand";
        // $body = "Hi \n This is your verification code : $rand";
        // $header = "from:dqbrand@gmail.com";
        // echo "$body";


        // if(mail($to, $subject, $body, $header)){
        //     $_SESSION['otp'] = $rand;
        //     echo "$rand";
            
        // }
        // else{
        //     echo"not found";
        // }
    }
    else{
        echo"not found!";
    }
    
    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foode.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
     <link rel="stylesheet" href="loginsignup.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

</head>
<body>
    <a href="index.html" class="btn">back</a>
  <center>
    <div class="container" id="signup" >
        <h1 class="form-title">reset</h1>
        <form method="post" action="">
            
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="email" placeholder="Email" required >
                
            </div>
            <br>
            <input type="submit" class="btn" value="Send" name="submit">




        </form>
        <p class="or">
            --------------or-------------
        </p>
    
        <div class="links">
            <p>Already Have Account ?</p>
             <a href="signin.php" id="signInButton" class="add">Sign In</a>
            <button ></button>

        </div>
   


    </div>
 </center>
    

  
     

    
    
 

    
  

    
    








 <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
 <script src="script.js"></script>
</body>
</html>