<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foode.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
     <link rel="stylesheet" href="loginsignup.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

</head>
<body>
    <a href="index.html" class="btn">back</a>
  <center>
    <div class="container" id="signup" >
        <h1 class="form-title">Reset Password</h1>
        <form method="post" action="">
            
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="pass" id="password" placeholder="Password" required >
                
            </div>
            <br>
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="pass" id="password" placeholder="Confirm Password" required >
                
            </div>
            <br>
            <input type="submit" class="btn" value="Send" name="signup">




        </form>
        <p class="or">
            --------------or-------------
        </p>
    
        <div class="links">
            <p>Already Have Account ?</p>
             <a href="signin.php" id="signInButton" class="add">Sign In</a>
            <button ></button>

        </div>
   


    </div>
 </center>
    

  
     

    
    
 