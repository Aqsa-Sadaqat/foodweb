<?php
  session_start();

  include('db.php');

  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
    $gmail = $_POST['email'];
    $password = $_POST['pass'];

    $checkuser = "SELECT * from form where email='$gmail'";
    $result = mysqli_query($con,$checkuser);
    $count = mysqli_num_rows($result);
    if($count>0){
        
        echo "<script type='text/javascript'> alert('Email is already exist here')</script>";
    }
    else{

  

    if(!empty($gmail) && !empty($password) && !is_numeric($gmail))
    {
        $query = "insert into form (fname, lname, email, pass) values ('$firstname','$lastname','$gmail','$password')";

        mysqli_query($con, $query);
        echo "<script type='text/javascript'> alert('Successfully Register')</script>";
        header("location: signin.php");

        
    }
    else
    {
        echo "<script type='text/javascript'> alert('Please enter some valid information')</script>";
    }
   }
  }

?>











<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foode.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
     <link rel="stylesheet" href="loginsignup.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

</head>
<body>
    <a href="index.html" class="btn">back</a>
  <center>
    <div class="container" id="signup" >
        <h1 class="form-title">Register</h1>
        <form method="post" action="">
            <div class="input-group">
                <i class="fa-solid fa-user"></i>
                <input type="text" name="fname" id="fname" placeholder="First name" required>
                


            </div>
            <br>
            
            <div class="input-group">
                <i class="fa-solid fa-user"></i>
                <input type="text" name="lname" id="lname" placeholder="Last Name" required >
                
            </div>
            <br>
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="email" placeholder="Email" required >
                
            </div>
            <br>
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="pass" id="password" placeholder="Password" required >
                
            </div>
            <br>
            <input type="submit" class="btn" value="Sign Up" name="signUp">




        </form>
       
        <div class="links">
            <p>Already Have Account ?</p>
             <a href="signin.php" id="signInButton" class="add">Sign In</a>
            <button ></button>

        </div>
   


    </div>
 </center>
    

  
     

    
    
 

    
  

    
    








 <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
 <script src="script.js"></script>
</body>
</html>