<?php
  session_start();

  include('db.php');

  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    $gmail = $_POST['email'];
    $password = $_POST['pass'];

    if(!empty($gmail) && !empty($password) && !is_numeric($gmail))
    {
        $query = "select *from form where email = '$gmail' limit 1 ";
        $result = mysqli_query($con, $query);

        if($result)
        {
            if($result && mysqli_num_rows($result) > 0)
            {
                $user_data = mysqli_fetch_assoc($result);

               
                if($user_data['pass'] == $password)
                {  
                    header("location: dashbaord.php");
                    die;
                }
            }
           
        }
        echo "<script type='text/javascript'> alert('Wrong Information')</script>";
    }
    else{
        echo "<script type='text/javascript'> alert('Wrong Information')</script>";

    }
  }



?>














<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foode.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
     <link rel="stylesheet" href="loginsignup.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

</head>
<body>
    <a href="index.html" class="btn">back</a>
  <center>
    <div class="container" id="signIn">
        <h1 class="form-title">Sign In</h1>
        <form method="post" action="" class="trt">
            
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="email" placeholder="Email" required >
               
            </div>
            <br>
            <div class="input-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="pass" id="password" placeholder="Password" required >
               
            </div>
            <br>
            <p class="recover">
                <a href="forgetpass.php">Recover Password</a>
            </p>
            <input type="submit" class="btn" value="Sign In" name="signIn">




        </form>
      
        <div class="links">
            <p>Don't Have account yet? </p>
            <a href="register.php" id="signUpButton">sign Up</a>
            <button ></button>

        </div>


    </div>
 </center>

  
     

    
    
 

    
  

    
    








 <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
 <script src="script.js"></script>
</body>
</html>