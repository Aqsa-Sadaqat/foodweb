<?php
  
   include('db.php');
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard.</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
     <link rel="stylesheet" href="dashboard.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

</head>
<body>
      
      
      <h3 class="logo">Foode.</h3>

      <div class="sidebar">
            <div class="sidebar-menu">
                  <span class="fas fa-home"></span>
                  <a href="#">Home</a>
            </div>
            <div class="sidebar-menu">
                  <span class="fas fa-search"></span>
                  <a href="#">Search</a>
            </div>
            <div class="sidebar-menu">
                  <span class="fas fa-heart"></span>
                  <a href="#">Favs</a>
            </div>
            <div class="sidebar-menu">
                  <span class="fa-solid fa-right-from-bracket"></span>
                  <a href="signin.php">logout</a>
            </div>
      </div>

      <div class="dashboard">
            <div class="dashboard-banner">
                  <img src="db.JPG" alt="">
                  
                  <div class="banner-promo">
                        <h1><span><b>50% OFF</b></span><br>
                  Tasty Food <br>On Your Hand</h1>
                  </div>
            </div>

            <h3 class="dashboard-title">Recommend Food For You</h3>
            <div class="dashboard-menu">
                  <a href="#">favourites</a>
                  <a href="#">Best Seller</a>
                  <a href="#">Near Me</a>
                  <a href="#">Promotion</a>
                  <a href="#">Top Rated</a>
                  
            </div>
            <div class="dashboard-content">
                  <div class="dashboard-card">
                        <a href="index2.html"><img class="card-image" src="pizzabanner.jpg" ></a>
                        <div class="card-details">
                           <h4>Amazing Pizza <span></span></h4>
                           <p>Delivery Time</p>
                           <p class="card-time"><span class="fas fa-clock"></span>15-30 mins</p>
                        </div>

                  </div>
            </div>
            <div class="dashboard-content">
                  <div class="dashboard-card">
                       
                        <a href="index2.html"><img class="card-image" src="saladbanner.jpg" ></a>
                        <div class="card-details">
                           <h4>Tasty Burger <span></span></h4>
                           <p>Delivery Time</p>
                           <p class="card-time"><span class="fas fa-clock"></span>15-30 mins</p>
                        </div>

                  </div>
            </div>
            <div class="dashboard-content">
                  <div class="dashboard-card">
                       
                        <a href="index2.html"><img class="card-image" src="sweetbanner.jpg" ></a>
                        <div class="card-details">
                           <h4>Fresh Sweets <span></span></h4>
                           <p>Delivery Time</p>
                           <p class="card-time"><span class="fas fa-clock"></span>15-30 mins</p>
                        </div>

                  </div>
            </div>
           
      </div>


      













      <!-- <a href="signin.php">logout</a> -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
 <script src="script.js"></script>
</body>
</html>
